<?php
$var = 'hello';
$num = -2;
$num2 = 3;
$nombre = 'Miguel';
$nacimiento = 2006;
$edad = 19;