<?php
$clickable = true;
$clickable2 = false;