<?php
class Persona {
    public $name;
    public function __construct($name) {
        $this->name = $name;
    }
}
$items = [];
$nombres = ["Miguel","Pedro","Maria"];
foreach ($nombres as $nombre) {
	$items[]=new Persona($nombre);
}


