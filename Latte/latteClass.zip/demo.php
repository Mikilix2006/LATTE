<?php

/** @link https://fiddle.nette.org/latte/#undefined */

if (@!include 'vendor/autoload.php') {
	echo "Install Latte using 'composer install'";
	exit(1);
}

include 'params.php';
$params = get_defined_vars();

$latte = new Latte\Engine;
$latte->setTempDirectory('temp');
$latte->render('main.latte', $params);
